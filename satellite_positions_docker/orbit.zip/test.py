from skyfield.api import Loader, EarthSatellite, load, wgs84
import math
import requests
import sys
from datetime import timedelta


def radians_to_degrees(radians):
    return radians * (180.0 / math.pi)

def satellite_coordinates_to_dd(latitude_rad, longitude_rad):
    latitude_dd = radians_to_degrees(latitude_rad)
    longitude_dd = radians_to_degrees(longitude_rad)
    return latitude_dd, longitude_dd

ts = load.timescale()
line1 = '1 25544U 98067A   14020.93268519  .00009878  00000-0  18200-3 0  5082'
line2 = '2 25544  51.6498 109.4756 0003572  55.9686 274.8005 15.49815350868473'
satellite_name = sys.argv[1]
#url = f"https://celestrak.org/NORAD/elements/gp.php?NAME={satellite_name}&FORMAT=tle"


#response = requests.get(url)
#tle_lines = response.text.splitlines()
#L1 = tle_lines[1]
#L2 = tle_lines[2]

load = Loader('~/Documents/fishing/SkyData')
ts = load.timescale()
satellite = EarthSatellite(line1, line2)
start_time = ts.now()
end_time = start_time.utc_datetime() + timedelta(hours=1)
interval = timedelta(minutes=0.5)
coords = []
current_time = start_time
while current_time.utc_datetime() < end_time:
    position = satellite.at(current_time)
    lat, lon = wgs84.latlon_of(position)
    height = wgs84.height_of(position)
    if height.km < 0:
        height = height.km * -1
    print(lat.degrees, lon.degrees, height * 1000)
    #latitude_rad = position.latitude.radians
    #longitude_rad = position.longitude.radians
    #
    #latitude_dd, longitude_dd = satellite_coordinates_to_dd(latitude_rad, longitude_rad)
    #
    #coords.append((latitude_dd, longitude_dd, altitude_km * 1000))
    #print (f"{latitude_dd},{longitude_dd},{altitude_km * 1000}")
    current_time = current_time + interval
